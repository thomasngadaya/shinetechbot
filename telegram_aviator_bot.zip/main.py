import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

BOT_TOKEN = os.getenv("BOT_TOKEN")

subscriptions = {
    "daily": 10000,
    "3days": 20000,
    "weekly": 30000,
    "monthly": 50000,
    "3months": 120000,
    "yearly": 500000,
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    welcome_text = "Karibu kwenye Aviator Prediction Bot! 🎉\n\nUnapata round 5 za bure. Baada ya hapo, tafadhali chagua kifurushi kuendelea."
    keyboard = [
        [InlineKeyboardButton("⚡Anza Round za Bure", callback_data="free_rounds")],
        [InlineKeyboardButton("💰 Lipa Kifurushi", callback_data="buy_package")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(welcome_text, reply_markup=reply_markup)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "free_rounds":
        await query.edit_message_text("✅ Unapata round zako 5 za bure. Zinaanza sasa...")
    elif data == "buy_package":
        keyboard = [
            [InlineKeyboardButton("📆 Siku 1 - 10,000 TZS", callback_data="pay_daily")],
            [InlineKeyboardButton("📆 Siku 3 - 20,000 TZS", callback_data="pay_3days")],
            [InlineKeyboardButton("📆 Wiki 1 - 30,000 TZS", callback_data="pay_weekly")],
            [InlineKeyboardButton("📆 Mwezi - 50,000 TZS", callback_data="pay_monthly")],
            [InlineKeyboardButton("📆 Miezi 3 - 120,000 TZS", callback_data="pay_3months")],
            [InlineKeyboardButton("📆 Mwaka - 500,000 TZS", callback_data="pay_yearly")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text("Chagua kifurushi cha malipo:", reply_markup=reply_markup)
    elif data.startswith("pay_"):
        pkg = data.replace("pay_", "")
        amount = subscriptions.get(pkg, 0)
        msg = f"""💳 Malipo kwa kifurushi: {pkg}

Chagua aina ya malipo:

💸 *Mobile Money*:
- Airtel: 0686823297
- Tigo: 0654542433
- Vodacom: 0756196420
- TTCL: 0613542433

🔐 Lipa kwa jina la huduma: *shinetechnology*

💰 *Bitcoin:* bc1ql0x8j6rqcp5hr9x7hzts98phxsn84pmrvtla5s
💰 *TRX (TRC20):* TSgtTsmabWghWgXnYU765NG3HCKwmLkrtg
💰 *USDT:* 0x528581c64e39015b371b7d6b2f1a2605821c8170

Tafadhali thibitisha malipo na utatumiwa link ya kujiunga na group.
"""
        await query.edit_message_text(msg, parse_mode="Markdown")

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print("Bot is running...")
    app.run_polling()
